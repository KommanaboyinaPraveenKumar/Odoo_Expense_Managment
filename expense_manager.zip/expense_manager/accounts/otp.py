# accounts/otp.py
import random
from django.core.mail import send_mail
from django.conf import settings

def send_otp_email(to_email):
    """
    Send OTP to a given email using Django's email backend.
    """
    number = random.randint(1111, 9999)
    subject = "Your OTP Code"
    message = f"Your OTP is: {number}"

    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [to_email],
            fail_silently=False,
        )
        return number
    except Exception as e:
        print(f"Failed to send OTP: {e}")
        return None
