# urls.py
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    # Role-specific login pages (extra kwargs passed to view)
    path("login/admin/", views.login_view, {"role": "admin"}, name="admin_login"),
    path("login/manager/", views.login_view, {"role": "manager"}, name="manager_login"),
    path("login/employee/", views.login_view, {"role": "employee"}, name="employee_login"),

    # Classic login / signup
    path("login/", views.login_view, name="login"),
    path("signup/", views.otp_signup, name="signup"),
    path("otp-signup/", views.otp_signup, name="otp_signup"),

    # Logout
    path("logout/", auth_views.LogoutView.as_view(next_page="home"), name="logout"),

    # Dashboards
    path("admin-dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("manager-dashboard/", views.manager_dashboard, name="manager_dashboard"),
    path("employee-dashboard/", views.employee_dashboard, name="employee_dashboard"),

    # Invitations & signup helpers
    path("invite/", views.invite_user, name="invite_user"),
    path("add-manager/", views.invite_user, name="add_manager"),
    path("add-employee/", views.invite_user, name="add_employee"),
    path("manager/add-user/", views.invite_user, name="manager_add_user"),

    # Home
    path("", views.home, name="home"),

    # Expense actions
    path("set-company-country/", views.set_company_country, name="set_company_country"),
    path("expense/<int:pk>/approve/", views.approve_expense, name="approve_expense"),
    path("expense/<int:pk>/reject/", views.reject_expense, name="reject_expense"),
    path("employee/submit-expense/", views.submit_expense_ajax, name="submit_expense_ajax"),
]
