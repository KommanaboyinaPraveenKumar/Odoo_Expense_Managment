# accounts/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
from datetime import timedelta
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.conf import settings


class Company(models.Model):
    name = models.CharField(max_length=255)
    country = models.CharField(max_length=100, blank=True, null=True)  # ✅ Allow blank initially
    currency = models.CharField(max_length=10, default="USD")

    def __str__(self):
        return self.name


class User(AbstractUser):
    ROLE_CHOICES = [
        ("employee", "Employee"),
        ("manager", "Manager"),
        ("admin", "Admin"),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, blank=True)
    company = models.ForeignKey(
        Company, on_delete=models.SET_NULL, null=True, blank=True, related_name="users"
    )
    manager = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True, related_name="team_members"
    )

    def is_admin(self):
        return self.role == "admin"

    def is_manager(self):
        return self.role == "manager"

    def is_employee(self):
        return self.role == "employee"


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_company_for_admin(sender, instance, created, **kwargs):
    """
    Auto-create a company when an admin user is created and no company is set.
    Default is USA/USD but you can later change it via admin panel or country API.
    """
    if created and instance.role == "admin" and not instance.company:
        company = Company.objects.create(
            name=f"{instance.username}'s Company",
            country="USA",
            currency="USD"
        )
        instance.company = company
        instance.save()


class OTP(models.Model):
    ROLE_CHOICES = [
        ("manager", "Manager"),
        ("employee", "Employee"),
    ]
    email = models.EmailField()
    code = models.CharField(max_length=6)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="employee")
    created_at = models.DateTimeField(auto_now_add=True)

    def is_valid(self):
        return timezone.now() <= self.created_at + timedelta(hours=1)

    def __str__(self):
        return f"{self.email} - {self.code} ({self.role})"


class OTPInvite(models.Model):
    email = models.EmailField()
    role = models.CharField(
        max_length=20,
        choices=[("manager", "Manager"), ("employee", "Employee")]
    )
    otp = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    def is_valid(self):
        """Valid if not used and within 1 hour of creation."""
        return (not self.is_used) and (timezone.now() <= self.created_at + timedelta(hours=1))

    def __str__(self):
        return f"{self.email} - {self.otp} ({'used' if self.is_used else 'unused'})"
