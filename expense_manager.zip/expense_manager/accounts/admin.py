from django.contrib import admin
from .models import User, Company, OTPInvite

class UserAdmin(admin.ModelAdmin):
    list_display = ("username", "email", "role", "company", "manager")
    list_filter = ("role", "company")
    search_fields = ("username", "email")

admin.site.register(User, UserAdmin)
admin.site.register(Company)
admin.site.register(OTPInvite)
