import random
import requests
from decimal import Decimal, InvalidOperation
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.contrib.auth import authenticate, login, get_user_model
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from expenses.models import Expense
from .models import OTP, Company
from .otp import send_otp_email

User = get_user_model()


# -------------------------------
# Helper functions
# -------------------------------
def is_admin(user):
    return user.is_superuser or getattr(user, "role", "") == "admin"


# -------------------------------
# Home & Login
# -------------------------------
def home(request):
    return render(request, "home.html")


def login_view(request):
    role = request.GET.get("role", "employee")
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        # ✅ Authenticate by email
        try:
            user_obj = User.objects.get(email=email)
            username = user_obj.username
        except User.DoesNotExist:
            return render(request, "accounts/login.html", {"error": "No account found with this email.", "role": role})

        user = authenticate(request, username=username, password=password)
        if user is not None and user.role == role:
            login(request, user)

            # ✅ Redirect based on role
            if user.is_admin():
                return redirect("admin_dashboard")
            elif user.is_manager():
                return redirect("manager_dashboard")
            else:
                return redirect("employee_dashboard")

        else:
            return render(request, "accounts/login.html", {"error": "Invalid credentials.", "role": role})

    return render(request, "accounts/login.html", {"role": role})


# -------------------------------
# Admin Dashboard with Country Selection
# -------------------------------
@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    company = request.user.company

    # 🌍 Prompt for country if missing
    if not company or not company.country:
        try:
            response = requests.get("https://restcountries.com/v3.1/all?fields=name,currencies", timeout=10)
            countries = []
            if response.status_code == 200:
                for c in response.json():
                    name = c.get("name", {}).get("common")
                    currencies = c.get("currencies", {})
                    currency_code = list(currencies.keys())[0] if currencies else "USD"
                    countries.append({"name": name, "currency": currency_code})
        except Exception as e:
            print("Country API error:", e)
            countries = []

        return render(request, "accounts/select_country.html", {"countries": countries})

    users = User.objects.all()
    expenses = Expense.objects.all().order_by('-date')
    return render(request, "accounts/admin_dashboard.html", {"users": users, "expenses": expenses})


@login_required
def set_company_country(request):
    if request.method == "POST":
        country = request.POST.get("country")
        currency = request.POST.get("currency")

        if not country or not currency:
            return JsonResponse({"success": False, "error": "Country and currency are required."}, status=400)

        company = request.user.company
        if not company:
            company = Company.objects.create(name=f"{request.user.username}'s Company")

        company.country = country
        company.currency = currency
        company.save()

        messages.success(request, f"Company country set to {country} ({currency}).")
        return redirect("admin_dashboard")

    return JsonResponse({"success": False, "error": "Invalid request."}, status=400)


# -------------------------------
# Employee Dashboard (Expense Submission)
# -------------------------------
@login_required
def employee_dashboard(request):
    if request.method == "POST" and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        amount = request.POST.get("amount")
        category = request.POST.get("category")
        description = request.POST.get("description", "")
        currency = request.POST.get("currency", "USD")  # Optional: allow employee to enter different currency

        if not amount or not category:
            return JsonResponse({"error": "Amount and category are required"}, status=400)

        try:
            amount = Decimal(amount)
        except InvalidOperation:
            return JsonResponse({"error": "Invalid amount format"}, status=400)

        # 🌍 Currency conversion
        company_currency = request.user.company.currency
        converted_amount = None

        if currency != company_currency:
            try:
                api_url = f"https://api.exchangerate-api.com/v4/latest/{currency}"
                res = requests.get(api_url, timeout=10)
                data = res.json()
                rate = data.get("rates", {}).get(company_currency)
                if rate:
                    converted_amount = Decimal(amount) * Decimal(rate)
            except Exception as e:
                print("Currency conversion failed:", e)

        expense = Expense.objects.create(
            company=request.user.company,
            submitted_by=request.user,
            amount=amount,
            currency=currency,
            converted_amount=converted_amount,
            category=category,
            description=description,
            status="Pending"
        )

        data = {
            "id": expense.id,
            "date": expense.date.strftime("%Y-%m-%d"),
            "category": expense.category,
            "description": expense.description,
            "amount": str(expense.amount),
            "currency": expense.currency,
            "converted_amount": str(expense.converted_amount) if expense.converted_amount else None,
            "status": expense.status
        }
        return JsonResponse({"message": "Expense submitted successfully", "expense": data})

    my_expenses = Expense.objects.filter(submitted_by=request.user).order_by('-date')
    return render(request, "accounts/employee_dashboard.html", {"my_expenses": my_expenses})


# -------------------------------
# Manager Dashboard
# -------------------------------
@login_required
def manager_dashboard(request):
    team_expenses = Expense.objects.filter(submitted_by__company=request.user.company).order_by('-date')

    if request.method == "POST" and "amount" in request.POST:
        amount = request.POST.get("amount")
        category = request.POST.get("category")
        description = request.POST.get("description", "")
        Expense.objects.create(
            company=request.user.company,
            submitted_by=request.user,
            amount=amount,
            category=category,
            description=description,
            status="Pending"
        )
        messages.success(request, "Expense added successfully!")
        return redirect("manager_dashboard")

    return render(request, "accounts/manager_dashboard.html", {"team_expenses": team_expenses})


# -------------------------------
# OTP Signup, Invite & Approvals
# -------------------------------
@login_required
def invite_user(request):
    if request.method == "POST":
        email = request.POST.get("email")
        role = request.POST.get("role", "employee")
        otp_code = send_otp_email(email)

        if otp_code:
            OTP.objects.create(email=email, code=otp_code, role=role)
            return JsonResponse({"message": f"OTP sent to {email}"})
        else:
            return JsonResponse({"message": "Failed to send OTP"}, status=400)

    return render(request, "accounts/invite_user.html")


def otp_signup(request):
    if request.method == "POST":
        email = request.POST.get("email")
        otp_input = request.POST.get("otp")
        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            otp_obj = OTP.objects.get(email=email, code=otp_input)
        except OTP.DoesNotExist:
            messages.error(request, "Invalid OTP or Email.")
            return render(request, "accounts/signup.html")

        if not otp_obj.is_valid():
            messages.error(request, "OTP expired. Please request again.")
            otp_obj.delete()
            return render(request, "accounts/signup.html")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered. Please login instead.")
            return redirect("login")

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            role=otp_obj.role
        )
        otp_obj.delete()
        messages.success(request, f"Signup successful as {user.role.capitalize()}! Please login.")
        return redirect("login")

    return render(request, "accounts/signup.html")


@login_required
@require_POST
def approve_expense(request, pk):
    exp = get_object_or_404(Expense, pk=pk)
    exp.status = "Approved"
    exp.save()
    return JsonResponse({"status": "Approved", "expense_id": pk})


@login_required
@require_POST
def reject_expense(request, pk):
    exp = get_object_or_404(Expense, pk=pk)
    exp.status = "Rejected"
    exp.save()
    return JsonResponse({"status": "Rejected", "expense_id": pk})

@login_required
def submit_expense_ajax(request):
    if request.method == "POST":
        try:
            user = request.user
            if not user.company:
                return JsonResponse({"success": False, "error": "You are not assigned to any company."})

            amount = request.POST.get('amount')
            category = request.POST.get('category')
            description = request.POST.get('description', '')
            receipt = request.FILES.get('receipt')

            if not amount or not category:
                return JsonResponse({"success": False, "error": "Amount and Category are required."})

            try:
                amount = Decimal(amount)
            except InvalidOperation:
                return JsonResponse({"success": False, "error": "Invalid amount format."})

            expense = Expense.objects.create(
                company=user.company,
                submitted_by=user,
                amount=amount,
                category=category,
                description=description,
                receipt=receipt
            )

            return JsonResponse({
                "success": True,
                "expense": {
                    "category": expense.category,
                    "amount": str(expense.amount),
                    "status": expense.status,
                    "date": expense.date.strftime('%Y-%m-%d')
                }
            })

        except Exception as e:
            import traceback
            print(traceback.format_exc())
            return JsonResponse({"success": False, "error": str(e)})

    return JsonResponse({"success": False, "error": "Invalid request method."})
