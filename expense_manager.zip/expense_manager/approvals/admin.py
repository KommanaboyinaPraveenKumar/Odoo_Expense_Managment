from django.contrib import admin
from .models import ApprovalStep, ApprovalRule
from expenses.models import Expense

admin.site.register(ApprovalStep)
admin.site.register(ApprovalRule)
admin.site.register(Expense)

