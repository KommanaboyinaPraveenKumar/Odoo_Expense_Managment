from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from expenses.models import Expense
from .models import ApprovalStep

@login_required
def pending_approvals(request):
    steps = ApprovalStep.objects.filter(approver=request.user, status="waiting")
    return render(request, "approvals/pending.html", {"steps": steps})

@login_required
def approve_expense(request, expense_id):
    expense = get_object_or_404(Expense, id=expense_id)
    step = expense.steps.filter(approver=request.user, status="waiting").first()

    if request.method == "POST":
        decision = request.POST["decision"]
        step.status = "approved" if decision == "approve" else "rejected"
        step.comment = request.POST.get("comment", "")
        step.save()

        if step.status == "approved":
            next_step = expense.steps.filter(step_order=step.step_order+1).first()
            if next_step:
                next_step.status = "waiting"
                next_step.save()
            else:
                expense.status = "approved"
                expense.save()
        else:
            expense.status = "rejected"
            expense.save()

        return redirect("pending_approvals")

    return render(request, "approvals/approve_expense.html", {"expense": expense})


from django.contrib.auth.decorators import user_passes_test

def admin_required(view_func):
    return user_passes_test(lambda u: u.is_authenticated and u.role == "admin")(view_func)

@admin_required
def override_approval(request, expense_id):
    expense = Expense.objects.get(id=expense_id)
    if request.method == "POST":
        decision = request.POST.get("decision")
        expense.status = decision
        expense.save()
        # Also mark all approval steps as approved/rejected
        for step in expense.steps.all():
            step.status = decision
            step.save()
        return redirect("all_expenses")

    return render(request, "approvals/override_approval.html", {"expense": expense})
@admin_required
def all_expenses(request):
    expenses = Expense.objects.all()
    return render(request, "approvals/all_expenses.html", {"expenses": expenses})
