from django.db import models
from accounts.models import User, Company
from expenses.models import Expense

class ApprovalStep(models.Model):
    expense = models.ForeignKey(Expense, on_delete=models.CASCADE, related_name="steps")
    approver = models.ForeignKey(User, on_delete=models.CASCADE)
    step_order = models.IntegerField()
    status = models.CharField(max_length=20, choices=[
        ('waiting','Waiting'),
        ('approved','Approved'),
        ('rejected','Rejected')
    ], default='waiting')
    comment = models.TextField(blank=True, null=True)
    decided_at = models.DateTimeField(null=True, blank=True)

class ApprovalRule(models.Model):
    RULE_TYPES = (
        ('percentage', 'Percentage'),
        ('specific', 'Specific Approver'),
        ('hybrid', 'Hybrid'),
    )
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name="approval_rules"  # <- changed
    )
    rule_type = models.CharField(max_length=20, choices=RULE_TYPES)
    percentage_threshold = models.IntegerField(null=True, blank=True)
    specific_approver = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="approval_rules_specific"  # <- changed
    )
