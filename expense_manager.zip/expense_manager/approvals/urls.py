from django.urls import path
from . import views

urlpatterns = [
    path("pending/", views.pending_approvals, name="pending_approvals"),
    path("approve/<int:expense_id>/", views.approve_expense, name="approve_expense"),
    path("all/", views.all_expenses, name="all_expenses"),
    path("override/<int:expense_id>/", views.override_approval, name="override_approval"),
]
