# expenses/models.py
from django.db import models
from accounts.models import Company, User


class Expense(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('escalated', 'Escalated'),
    ]

    company = models.ForeignKey(
        Company, on_delete=models.CASCADE, related_name="expenses"
    )
    submitted_by = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="expenses"
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    currency = models.CharField(max_length=10, default="USD")
    converted_amount = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        help_text="Amount converted to company currency"
    )
    category = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    date = models.DateField(auto_now_add=True)
    receipt = models.ImageField(upload_to="receipts/", null=True, blank=True)
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='pending'
    )
    escalated = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def can_manager_approve(self):
        """Check if this expense is within the manager's approval limit."""
        # Optional feature: Add an ApprovalRule model later
        try:
            rule = self.company.approval_rule
            return self.amount <= rule.manager_approval_limit
        except AttributeError:
            # If no rule defined, allow approval by default
            return True

    def __str__(self):
        return f"{self.submitted_by} - {self.amount} {self.currency} ({self.status})"
