from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Expense
from .ocr import extract_text_from_receipt, parse_receipt
from .utils import convert_currency
from django.views.decorators.csrf import csrf_exempt

@login_required
def submit_expense(request):
    user = request.user
    company_currency = user.company.currency if getattr(user, 'company', None) else "USD"

    if not getattr(user, 'company', None):
        return render(request, "expenses/submit_expense.html", {
            "error": "Your user is not associated with a company.",
            "company_currency": company_currency
        })

    if request.method == "POST":
        mode = request.POST.get("mode", "manual")

        if mode == "manual":
            submitted_currency = request.POST.get("currency", company_currency)
            amount = float(request.POST["amount"])
            description = request.POST["description"]

            if submitted_currency != company_currency:
                amount = convert_currency(amount, submitted_currency, company_currency)

            Expense.objects.create(
                company=user.company,
                submitted_by=user,
                date=request.POST["date"],
                category=request.POST["category"],
                description=description,
                amount=amount,
                currency=company_currency,
                status="pending",
                receipt=request.FILES.get("receipt")
            )

        elif mode == "autofill" and request.FILES.get("receipt"):
            text = extract_text_from_receipt(request.FILES["receipt"])
            data = parse_receipt(text, company_currency=company_currency)

            Expense.objects.create(
                company=user.company,
                submitted_by=user,
                date=data.get("date") or None,
                category=data.get("category") or "",
                description=data.get("description") or "",
                amount=data.get("amount") or 0.0,
                currency=company_currency,
                receipt=request.FILES["receipt"],
                status="pending",
            )

        return redirect("my_expenses")

    return render(request, "expenses/submit_expense.html", {"company_currency": company_currency})

# AJAX endpoint for autofill
@csrf_exempt
@login_required
def autofill_receipt(request):
    if request.method == "POST" and request.FILES.get("receipt"):
        try:
            text = extract_text_from_receipt(request.FILES["receipt"])
            data = parse_receipt(text, company_currency=request.user.company.currency)
            return JsonResponse({"success": True, **data})
        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)})
    return JsonResponse({"success": False, "error": "No receipt uploaded"})


@login_required
def my_expenses(request):
    expenses = Expense.objects.filter(submitted_by=request.user)
    return render(request, "expenses/my_expenses.html", {"expenses": expenses})
