from django.urls import path
from . import views

urlpatterns = [
    path("submit/", views.submit_expense, name="submit_expense"),
    path("my/", views.my_expenses, name="my_expenses"),
    path("autofill/", views.autofill_receipt, name="autofill_receipt"),
]
