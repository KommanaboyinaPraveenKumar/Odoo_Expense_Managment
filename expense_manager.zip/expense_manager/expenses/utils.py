import requests
import pytesseract
from PIL import Image

def convert_to_company_currency(amount, from_currency, to_currency):
    try:
        url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
        data = requests.get(url).json()
        rate = data["rates"].get(to_currency, 1)
        return round(float(amount) * rate, 2)
    except Exception:
        return amount

def process_receipt_ocr(expense):
    if not expense.receipt:
        return
    img = Image.open(expense.receipt)
    text = pytesseract.image_to_string(img)

    import re
    match = re.search(r"(\d+\.\d{2})", text)
    if match:
        expense.amount = float(match.group(1))
        expense.converted_amount = convert_to_company_currency(expense.amount, expense.currency, expense.company.currency)
        expense.save()

import requests

def convert_currency(amount, from_currency, to_currency):
    url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
    response = requests.get(url)
    data = response.json()
    rate = data["rates"].get(to_currency)
    if rate:
        return round(amount * rate, 2)
    return amount  # fallback if rate not found
