from PIL import Image
import pytesseract
import re
from datetime import datetime

def extract_text_from_receipt(file):
    """Extract plain text from receipt image or PDF"""
    img = Image.open(file)
    text = pytesseract.image_to_string(img)
    return text

def parse_receipt(text, company_currency="USD"):
    """
    Extract date, amount, category, description from OCR text.
    Returns a dict.
    """

    # --- Date detection ---
    # Matches dd/mm/yyyy, dd-mm-yyyy, yyyy-mm-dd etc.
    date_patterns = [
        r'\b(\d{2}[/-]\d{2}[/-]\d{4})\b',
        r'\b(\d{4}[/-]\d{2}[/-]\d{2})\b'
    ]
    date = None
    for pattern in date_patterns:
        match = re.search(pattern, text)
        if match:
            try:
                date = datetime.strptime(match.group(1), "%d/%m/%Y").date()
            except:
                try:
                    date = datetime.strptime(match.group(1), "%d-%m-%Y").date()
                except:
                    try:
                        date = datetime.strptime(match.group(1), "%Y-%m-%d").date()
                    except:
                        pass
            if date:
                break

    # --- Amount detection ---
    # Looks for currency symbols or numbers like $12.34, 12.34 USD
    amount_patterns = [
        r'\$?(\d+\.\d{2})',
        r'(\d+\.\d{2})\s*' + company_currency
    ]
    amount = None
    for pattern in amount_patterns:
        match = re.search(pattern, text)
        if match:
            amount = float(match.group(1))
            break

    # --- Category detection ---
    # Simple keyword-based; you can enhance with ML later
    categories = ["Food", "Travel", "Office Supplies", "Entertainment", "Transport"]
    category = "General"
    for cat in categories:
        if cat.lower() in text.lower():
            category = cat
            break

    # --- Description ---
    # Take first few lines of OCR text as description
    description_lines = text.splitlines()
    description_lines = [line for line in description_lines if line.strip()]
    description = "\n".join(description_lines[:5])  # first 5 lines

    return {
        "date": date.isoformat() if date else "",
        "amount": amount if amount else "",
        "category": category,
        "description": description,
        "currency": company_currency
    }
